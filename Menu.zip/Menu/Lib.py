#!/bin/python3
import os
from time import sleep
import pyshorteners
import smtplib
import getpass
import sys
import time
from queue import Queue
from optparse import OptionParser
import time,sys,socket,threading,logging,urllib.request,random
import sys
import requests
import argparse
from email.utils import getaddresses
import json
#Author TAC
#USE AT YOUR OWN RISK!
def opened():
    os.system('chmod +x menu')
    os.system('clear')

def url():
    os.system('cd Scripts && python3 fakeurl')
def Cupp():
    os.system('cd Scripts && python3 cupp.py -i')
def Bomb():
    os.system('cd Scripts && proxychains python Email-bomber.py')
def DDOS():
    IP = input("\nEnter The Ip of the server:")
    os.system('cd Scripts && python3 hammer.py -s '+IP)
def pwnd():
    target = input("\nEnter The Target Email Please:")
    os.system('cd Scripts && python3 pwnd --target '+target +" --output txt")
    
def tor():
    os.system('cd Scripts && sudo bash torstart')
def wifii():
    os.system('cd Scripts && sudo bash wifi')
    os.system('./menu')
def Gmailbr():
    os.system('cd Scripts && proxychains sudo bash brute-gmail')
    
def Setoolk():
    os.system('sudo bash setoolkit')
    
def waf():
    Site = input("\nEnter The Site Name Please ex. checkra.in :")
    os.system('wafw00f '+Site)
def ungu():
     os.system('sudo uniscan-gui')
    
def sslAn():
    IP = input("\n Enter the IP Please:")
    os.system('sudo sslscan '+IP)
    
def Ping():
    Sitename = input("\n Enter the Site name Please:")
    os.system('ping '+Sitename)
    os.system('./menu')
def trace():
    IP = input("\nEnter The IP Please:")
    os.system('trace -t '+IP)
    os.system('./menu')
def ettercap():
    os.system('sudo ettercap -G')
    os.system('./menu')
def kato():
    os.system('cd Scripts && chmod +x katoolin.py && sudo python katoolin.py')
    os.system('./menu')

def r():
    print('\033[92m'"|------------------------------------------------------ |")
    print("|  This Script has been made by TAC                     |")
    print("|  Menu  TAC                                            |")
    print("|                                                       |")
    print('\033[93m'"|            Author: TAC                      |")
    print('\033[1m'"| Select the one you want:                              |")
    print('\033[94m'"| 1:FakeUrl 2:Cupp 3:Email-Bomber 4:DDOS                |")
    print("| 5:PWNDB 6:Start Tor 7:Wifi Service                    |")
    print("| 8:Brute-Gmail 9: Setoolkit 10:wafw00f 11: uniscan-gui |")
    print('\033[91m'"| 12: SSLAnalysis 13: ping site 14:Trace ip             |")
    print("| 15: Ettercap 16: install kali tools - all             |")
    print("| 17: ShellShock exploit - TAC  18: Metasploit-Framework|")
    print("| 19: Setoolkit  20: Exploit Database           0: exit |")
    print("--------------------------------------------------------|")

def mm():
    select = int(input('\033[91m'"\nSelect a option: "))
    if select == 1:
        url()
    elif select == 2:
        Cupp()
    elif select == 3:
        Bomb()
    elif select == 4:
        DDOS()
    elif select == 5:
        pwnd()
    elif select == 6:
        tor()
    elif select == 7:
        wifii()
    elif select == 8:
        Gmailbr()
    elif select == 9:
        Setoolk()
    elif select == 10:
        waf()
    elif select == 11:
        ungu()
    elif select == 12:
        sslAn()
    elif select == 13:
        Ping()
    elif select == 14:
        trace()
    elif select == 15:
        ettercap()
    elif select == 16:
        kato()
    elif select == 17:
        os.system('cd Scripts && chmod +x shellshock_TAC.py && python shellshock_TAC.py')
    elif select == 18:
        os.system('msfdb init && msfconsole')
    elif select == 19:
        os.system('setoolkit')
    elif select == 20:
        os.system('chromium %U --no-sandbox https://www.exploit-db.com/')
    elif select == 0:
        os.system('clear')
        print('\033[91m'"Goodbye...")
        exit()
    else:
        print("Invalid Option...")
        os.system('./menu')
